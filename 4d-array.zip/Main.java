import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Enetr the Container of array");
		Scanner scan = new Scanner(System.in);
		int l = scan.nextInt();
		
		System.out.println("Enetr the Block of array");
		int b = scan.nextInt();
		
		System.out.println("Enetr the Rows of array");
		int r = scan.nextInt();
		
		System.out.println("Enetr the Column of array");
		int c = scan.nextInt();
		
		int[][][][] a = new int[l][b][r][c];
		for(int i = 0;i < l; ++i)
		{
		    for(int j = 0;j < b; ++j)
		    {
		        for(int k = 0;k < r; ++k)
		        {
		            for(int x = 0;x < c; ++x)
		            {
		                a[i][j][k][x] = scan.nextInt();
		            }
		        }
		    }
		}
		
		for(int i = 0;i < l; ++i)
		{
		    for(int j = 0;j < b; ++j)
		    {
		        for(int k = 0;k < r; ++k)
		        {
		            for(int x = 0;x < c; ++x)
		            {
		                System.out.println(a[i][j][k][x] + " ");
		            }
		        }
		    }
		}
	}
}


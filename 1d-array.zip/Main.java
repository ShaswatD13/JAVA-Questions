import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    
	    System.out.println("Enter the size of array");
	    Scanner scan = new Scanner(System.in);
	    int n = scan.nextInt();
	    
		int[] a = new int[n];
		for(int i = 0;i < n; ++i)
		{
		    a[i] = scan.nextInt();
		}
		
		for(int i = 0;i < n; ++i)
		{
		    System.out.println(a[i]);
		}
		
	}
}

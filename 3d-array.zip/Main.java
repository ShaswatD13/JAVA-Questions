import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Enter the Block of array");
		Scanner scan = new Scanner(System.in);
		int b = scan.nextInt();
		
		System.out.println("Enter the Rows of array");
		int r = scan.nextInt();
		
		System.out.println("Enter the Column of array");
		int c = scan.nextInt();
		
		int[][][] a = new int[b][r][c];
		for(int i = 0;i < b; ++i)
		{
		    for(int j = 0;j < r; ++j)
		    {
		        for(int k = 0;k < c; ++k)
		        {
		            a[i][j][k] = scan.nextInt();
		        }
		    }
		}
		
		for(int i = 0;i < b; ++i)
		{
		    for(int j = 0;j < r; ++j)
		    {
		        for(int k = 0;k < c; ++k)
		        {
		            System.out.println(a[i][j][k] + " ");
		        }
		    }
		}
	}
}

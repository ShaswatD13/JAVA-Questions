import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Enter the rows of array");
		Scanner scan = new Scanner(System.in);
		int r = scan.nextInt();
		
		System.out.println("Enter the column of array");
		int c = scan.nextInt();
		
		int[][] a = new int[r][c];
		for(int i = 0;i < r; ++i)
		{
		    for(int j = 0;j < c; ++j)
		    {
		        a[i][j] = scan.nextInt();
		    }
		}
		
		for(int i = 0;i < r; ++i)
		{
		    for(int j = 0;j < c; ++j)
		    {
		        System.out.println(a[i][j] + " ");
		    }
		    System.out.println("\n");
		}
	}
}
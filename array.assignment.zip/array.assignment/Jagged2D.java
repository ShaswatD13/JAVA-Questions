import java.util.Scanner;
public class Jagged2D
{
	public static void main(String[] args) {
	int r,c=0;
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the number of rows:");
	r=scan.nextInt();
	int [][] arr=new int[r][];
	for(int i=0;i<r;i++){
	    System.out.println("Enter the number of students in classroom"+(i+1)+":");
	    int students=scan.nextInt();
	    arr[i]=new int[students];
	   for(int j=0; j<students; j++){
	       System.out.println("Enter the marks of student:");
	       arr[i][j]=scan.nextInt();
	   }
	}
	for(int i=0; i<r; i++){
	 System.out.println("marks scored by student in classroom"+ (i+1) +":");
	    for(int j=0; j<arr[i].length;j++){
	        System.out.println("Marks scored by student is:"+arr[i][j]);
	    }
	}
	
	}
}
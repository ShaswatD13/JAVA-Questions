import java.util.Scanner ;
public class case1 {
        public static void main(String[] args) {
        //case 1(1 dimension)
        int[] a = new int[5];
        Scanner scan = new Scanner(System.in);
        for(int i = 0;i < 5 ; i++){
            a[i] = scan.nextInt();
        }
        System.out.println("The marks are: ");
        for(int i = 0;i < 5 ; i++){
            System.out.print(a[i] + " ");
        }
    }
}

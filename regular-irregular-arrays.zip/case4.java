import java.util.Scanner;
public class case4 {
    public static void main(String[] args){
        //case 4(4 dimension)
        int[][][][] a = new int[2][2][3][5];
        Scanner scan = new Scanner(System.in);
        for(int h = 0;h<2;h++){
            for(int i = 0;i<2;i++){
                for(int j = 0; j< 3;j++){
                    for(int k = 0;k<5;k++){
                        a[h][i][j][k] = scan.nextInt();
                    }
                }
            }
        }
        System.out.println("The marks are :");
        for(int h = 0;h<2;h++){
            for(int i = 0;i<2;i++){
                for(int j = 0; j< 3;j++){
                    for(int k = 0;k<5;k++){
                        System.out.print(a[h][i][j][k] + " ");
                    }
                    System.out.print("\n");
                }
                System.out.print("\n");
            }
            System.out.print("\n");
        }
    }
}

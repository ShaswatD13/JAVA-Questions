import java.util.Scanner;
public class case5 {
    public static void main(String[] args){
        //case 5( 2D jagged array)
        int[][] a = new int[3][];
        a[0] = new int[5];
        a[1] = new int[3];
        a[2] = new int[4];
        
        Scanner scan = new Scanner(System.in);
        for(int i =0 ;i<3;i++){
            if(i==0)
                for(int j=0;j<5;j++)
                    a[i][j] = scan.nextInt();
            else if(i==1)
                for(int j=0;j<3;j++)
                    a[i][j] = scan.nextInt();
            else
                for(int j=0;j<4;j++)
                    a[i][j] = scan.nextInt();
        }
        System.out.println("The marks are: ");
        for(int i =0; i<3;i++){
            if(i==0)
                for(int j=0;j<5;j++){
                     System.out.print(a[i][j] + " ");
                }
            else if(i==1)
                for(int j=0;j<3;j++){
                     System.out.print(a[i][j] + " ");
                }
            else
                for(int j=0;j<4;j++){
                    System.out.print(a[i][j] + " ");
                }
            System.out.print("\n");
        }
    }   
}

import java.util.Scanner;
public class case2 {
    public static void main(String[] args){
        //case 2(2 dimension)
        int[][] a = new int[3][5];
        Scanner scan = new Scanner(System.in);
        for(int i = 0;i < 3;i++){
            for(int j = 0;j<5;j++){
                a[i][j] = scan.nextInt();
            }
        }
        System.out.println("The marks are: ");
        for(int i = 0;i < 3;i++){
            for(int j = 0;j<5;j++){
                System.out.print(a[i][j] + " ");
            }
            System.out.print("\n");
        }
    }
}

import java.util.Scanner;

public class case3 {
    public static void main(String[] args){
        //case 3(3 dimension)
        int[][][] a = new int[2][3][5];
        Scanner scan = new Scanner(System.in);
        for(int i = 0;i<2;i++){
            for(int j = 0; j< 3;j++){
                for(int k = 0;k<5;k++){
                    a[i][j][k] = scan.nextInt();
                }
            }
        }
        System.out.println("The marks are :");
        for(int i = 0;i<2;i++){
            for(int j = 0; j< 3;j++){
                for(int k = 0;k<5;k++){
                    System.out.print(a[i][j][k] + " ");
                }
                System.out.print("\n");
            }
            System.out.print("\n");
        }
    }
}

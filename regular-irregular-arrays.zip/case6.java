import java.util.Scanner;
public class case6 {
    public static void main(String[] args){
        //case 6(3D jagged array)(easy vala)
        int[][][] a = new int[2][][];
        a[0] = new int[2][5];
        a[1] = new int[3][5];
        
        Scanner scan = new Scanner(System.in);
        for(int i =0 ;i<2;i++){
            if(i==0)
                for(int j=0;j<2;j++){
                    for(int k=0;k<5;k++){
                        a[i][j][k] = scan.nextInt();
                    }
                }
            else
                for(int j=0;j<3;j++){
                    for(int k=0;k<5;k++){
                        a[i][j][k] = scan.nextInt();
                    }
                }
        }
        System.out.println("The marks are: ");
        for(int i =0 ;i<2;i++){
            if(i==0)
                for(int j=0;j<2;j++){
                    for(int k=0;k<5;k++){
                        System.out.print(a[i][j][k] + " ");
                    }
                    System.out.print("\n");
                }
            else
                for(int j=0;j<3;j++){
                    for(int k=0;k<5;k++){
                        System.out.print(a[i][j][k] + " ");
                    }
                    System.out.print("\n");
                }
            System.out.print("\n");
        }
    }

}
